
import './App.css';
import Fd from './components/conector/index'
function App() {
  return (
    <div className="App">
    <Fd/>
    </div>
  );
}

export default App;
